<?php
include("header.php");
?>
<?php

$sql = "SELECT titre, article_preview, date, pseudo, image FROM article WHERE type_1 = 'illustration' ORDER BY id DESC LIMIT 0, 10";
$affichage_article= $bdd->query($sql);

	
?>
<div class="index_affichage_article">
	<div class="colonne">
<?php

while ($donne = $affichage_article->fetch() )
{
?>
<div class="article">





  
    <img src="image/<?php echo $donne['image']; ?>" /></br>

    <?php
    echo $donne['titre'], "<br/>", "</br>";
    echo "Article publie par ", $donne['pseudo'], " le ", $donne['date'], "<br/>", "</br>";
echo $donne['article_preview'], "...", "<br/>";

?>
</div>
<?php

}
?>


<?php 

$affichage_article->closeCursor();
?>
</div>

</div>
<?php

include("footer.php");
?>