<?php
include("header.php");


?>
<div class="validation">


<?php
  
   	echo "Vous avez ete deconnecte ! ";
    $_SESSION['pseudo'] = 0;
    $_SESSION['id'] = 0;
?>   

    
 

</div>
<?php
header ("Refresh: 2;URL=index.php");
include("footer.php");
?>