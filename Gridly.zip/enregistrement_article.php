<?php
$_SESSION['pseudo'] = "";
include("header.php");
$erreur = 0;
?>

<?php
"<div class='inscription2'>";
if (empty($_SESSION['pseudo']))
{
	echo "vous devez etre enregistre en tant que membre pour pouvoir poster des articles !";
	$erreur++;
}
"</div>";
if ($erreur == 0) {

?>

<div class="enregistrement_formulaire">
<h2>Veuillez renseigner toutes les informations pour enregistrer un article</h2>
 <form method="post" action="previsualiser.php" enctype="multipart/form-data">
     <input type="text" name="titre" placeholder="entrer le titre de l'article" size="10"></br>
   
     <input type="date" name="date" placeholder="entrer la date" size="10"></br>
     
     <input type="text" name="pseudo" placeholder="pseudo" size="10"></br>
     <div class="image_upload">
      <label for="image">Fichier a uploader : </label><br />
     
     <input type="file" name="image" id="image"></br>
     </div>
     <label for="type">Type de l'article ( obligatoire ) : </label></br>
     <select name="type">
         <option value="photographie">Photographie</option>
         <option value="identity">Identity</option>
         <option value="illustration">Illustration</option>
     </select>
     <select name="type2">
         <option value="photographie">Photographie</option>
         <option value="identity">Identity</option>
         <option value="illustration">Illustration</option>
     </select>


     <textarea name="contenu" placeholder="Contenu" rows="40" cols="140"></textarea></br>
     <input type="submit" value="previsualiser">
   
   <?php
}

?>
 </form>
</div>
<?php

include("footer.php");
?>