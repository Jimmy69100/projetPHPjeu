<?php
include("header.php");
?>
<div class="inscription">
<h2>Voici le formulaire d'inscription, veuillez remplir tout les champs pour valider</h2>

 <form method="post" action="insertion_utilisateur.php">
     <input type="text" name="pseudo" placeholder="votre pseudo (15 maximum)" size="35"></br>
     <input type="email" name="mail" placeholder="votre mail" size="35"></br>
     <input type="password" name="mdp" placeholder="votre mot de passe" size="35"></br>
     <input type="password" name="mdp2" placeholder="verifier votre mot de passe" size="35"></br>
     <input type="submit" value="enregistrement">
   
 </form>
</div>
<?php
   
include("footer.php");
?>