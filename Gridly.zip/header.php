<?php
session_start();

include("BDD.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html" charset="iso-8859-1"/>
<link rel="stylesheet" href="css.css"/>

<title>
  Gridly
</title>
</head>
<header>
<body background="background.jpg">
<div class="police">
   <div class="header">
   <div class="titre_h1">
    <h1>Gridly</h1>
    </div>
    <div class="pseudo_connecte">
    <?php
    if (!empty($_SESSION['pseudo'])) {
    	echo "Bonjour ", $_SESSION['pseudo'];
    }
    ?>
    </div>
    <div class="home_lien">
    <ul>
      <li><a class="home" href="index.php">home</a></li>
      <li><a class="photography" href="photography.php">Photography</a></li>
      <li><a class="Illustration" href="Illustration.php">Illustration</a></li>
      <li><a class="identity" href="identity.php">Identity</a></li>
      <li><a class="about_me" href="about.php">about me</a></li>
      <li><a class="contact" href="contact.php">contact</a></li>
      <li><a class="enregistrer" href="enregistrement_article.php">mettre un article en ligne</a></li>
      </ul>
           <ul id="menu">
               <li><a class="utilisateur" href="#">Panneau utilisateur</a>
                  <ul class="sous-menu">
                       <?php
                 if (empty($_SESSION['pseudo']))
                 {
                  ?>
                  <li><a class="connexion" href="connexion.php">connexion</a></li>
                          <li><a href="inscription.php">Inscription</a></li>
                 <?php }
                 if (!empty($_SESSION['pseudo']))
          {
            ?>
              <li><a class="deconnection" href="deconnection.php">deconnexion</a></li>
              <li><a href="gestion.php">Gerer mon profil</a></li>
              <?php
             }
               ?>
               </ul>
               </li>
               </ul>
      </div>
      
     </div>
     </header>
