<?php
include("header.php");


?>
<div class="inscription">
<?php 
   if (!empty($_SESSION['pseudo'])) {
   	



  
   	echo "Vous etes deja connecte ! ";
   }

     else {
    	?>
    	<h2>Veuillez entrer vos informations pour vous connecter</h2>
 <form method="post" action="validation_connexion.php">
     <input type="text" name="pseudo" placeholder="votre pseudo (15 maximum)" size="35"></br>
     <input type="password" name="mdp" placeholder="votre mot de passe" size="35"></br>
     <input type="submit" value="connexion">
   
 </form>
 <?php
}
?>
</div>
<?php

include("footer.php");
?>