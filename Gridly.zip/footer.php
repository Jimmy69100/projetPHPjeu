<div class="footer">
<div class="footer_lien">
 <ul>
      <li><a href="facebook.com"><img src="facebook.jpg" class="facebook" /></a></li>
      <li><a href="twitter.com"><img src="twitter.jpg" class="twitter" /></a></li>
      <li><a href=""><img src="rss.jpg" class="rss" /></a></li>
      <li><a href=""><img src="mail.jpg" class="mail" /></a></li>
      </ul>
      </div>
      <div class="footer_text">
      </div>
      </div>
      </div>
<p>This website & the internet Ends here -></p>
</div>
<p>Copyright 2011 Showcase Design www.BlazRobar.com</p>
</div>
</body>
</html>