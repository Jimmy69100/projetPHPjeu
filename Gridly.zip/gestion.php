<?php
include("header.php");


?>
<div class="gestion">
<h1>Bienvenue dans votre interface de gestion d'utilisateur</h1>
 <p>Vous pouvez a partir de cette interface modifier vos information de compte, le nombre d'article
  correspondant a votre profile et modifier votre avatar</p></br></br>



  <div class="info">
  <h3>Vos informations : </h3>
<?php
  $sql = "SELECT pseudo, mail, date_inscription FROM utilisateur WHERE pseudo = :pseudo";
  $req = $bdd->prepare($sql);
  $req->execute(array(
    'pseudo' => $_SESSION['pseudo']
    ));

  while ($donne = $req->fetch() ) {
    echo "Votre pseudo : ", $donne['pseudo'], "</br>";
    echo "votre adresse mail : ", $donne['mail'], "</br>";
    echo "votre date d'inscription : ", $donne['date_inscription'], "</br>";
  }
  $req->closeCursor();
?>
</div>

<div class="modification">

<h3>Modification des infos</h3>
<p>changer votre adresse mail : </p>
<form method="post" action="nouveau-mail.php">
   <input type="email" name="mail" placeholder="entrez votre nouveau mail" size="35"></br></br>
    <input type="submit" value="enregistrement">

</form>
</div>

<?php
$sql = "SELECT titre, article_preview, date, pseudo, image FROM article WHERE pseudo = :pseudo ORDER BY id DESC LIMIT 0, 10";
$req2 = $bdd->prepare($sql);
$req2->execute(array(
  'pseudo' => $_SESSION['pseudo']
  ));
?>
<div class="article_titre">
   <h4>Voici la liste de vos articles : </h4>
   <?php
   while ($donnee = $req2->fetch() ) {
    echo $donnee['titre'], " ", "publie le : ", $donnee['date'], 
    "<div class='menu_util'><a href='#.com'>Voir</a>"," ", "<a href='#.com'>Supprimer</a></div>", "</br>", "</br>";



   }
?>




</div>



<?php
include("footer.php");
  ?>