<?php
include("header.php");
?>
<?php

$reponse = $bdd->prepare("DELETE FROM article WHERE pseudo = :pseudo AND titre = :titre"); //Commande pour la requête SQL
$reponse->execute(array(
	'pseudo' => $_SESSION['pseudo2'],
	'titre' => $_SESSION['titre2']
	));



echo "Votre article a bien ete efface !";
	?>





</div>
<?php

include("footer.php");
?>