<?php
include("header.php");
$erreur = 0;
$mdp = $_POST['mdp'];
$mdp2 = $_POST['mdp2'];
$pseudo = $_POST['pseudo'];
?>





<?php
if ($mdp != $mdp2 || empty($mdp) || empty($mdp2))
{
	echo "Les mots de passes ne sont pas correspondant, veuillez reesseyer.";
	$erreur++;
}

$sql = "SELECT id FROM utilisateur WHERE pseudo = :pseudo";
// Vérification des identifiants
$req = $bdd->prepare($sql);
$req->execute(array(
    'pseudo' => $pseudo   
    ));

$verification_pseudo = $req->rowCount();

if ($verification_pseudo > 0)
   {
   	 echo "votre pseudo est deja utilise, veuillez en choisir un autre";
   	 $erreur++;
   }
$req->CloseCursor();




if ($erreur == 0) {


$pass_hache = sha1($_POST['mdp']);

$req2 = $bdd->prepare('INSERT INTO utilisateur(pseudo, mail, mdp, date_inscription) VALUES(:pseudo, :mail, :mdp, CURDATE())');
$req2->execute(array(
    'pseudo' => $_POST['pseudo'],
    'mdp' => $pass_hache,
    'mail' => $_POST['mail']
    ));




?>
<h3>Felicitation, vous etes maintenant inscrit sur notre site!</h3>

<?php
}
?>



<?php

include("footer.php");
?>