<?php
include("header.php");
$pass_hache2 = sha1($_POST['mdp']);
$_SESSION['pseudo'] = 0;
?>
<div class="validation">
<?php
$pseudo = $_POST['pseudo'];
$sql = "SELECT id FROM utilisateur WHERE pseudo = :pseudo AND mdp = :mdp";
// Vérification des identifiants
$req = $bdd->prepare($sql);
$req->execute(array(
    'pseudo' => $pseudo,
    'mdp' => $pass_hache2
    ));

$resultat = $req->rowCount();





if ($resultat == 0)
{
    echo 'Identifiant incorrect !';

}
else
{
    $_SESSION['id'] = $resultat['id'];
    $_SESSION['pseudo'] = $pseudo;
    echo 'Vous etes connecte !';
   

}

$req->closeCursor();

?>

</div>


<?php
header ("Refresh: 2;URL=index.php");
include("footer.php");
?>