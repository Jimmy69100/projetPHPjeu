<?php
include("header.php");


?>

<?php include("validation.php");
$pseudo = $_POST['pseudo'];
$titre = $_POST['titre'];
$_SESSION['pseudo2'] = $pseudo;
$_SESSION['titre2'] = $titre;

?>


<?php

$reponse = $bdd->prepare("SELECT titre, article, date, pseudo, image FROM article WHERE pseudo = :pseudo AND titre = :titre LIMIT 0, 1"); //Commande pour la requête SQL
$reponse->execute(array(
	'pseudo' => $pseudo,
	'titre' => $titre
	));
	?>
	<div class="previsualiser"> 
	<?php
while ($donne = $reponse->fetch() ) 
{




    echo "article publie par ", $pseudo, " le ", $_POST['date'], "</br>", "</br>";
    echo $donne['titre'], "</br>";
    ?>
    <img src="image/<?php echo $donne['image']; ?>" /></br>
    <?php
    echo $donne['image'];
    echo $donne['article'];
	

}

?>
<div class="valid_article">
<a class="valider" href="index.php">Valider l'envoi</a>
<a class="annuler" href="annulation.php">Effacer l'article</a> 
</div>
<?php
?>

</div>





<?php

include("footer.php");
?>