<?php
include("header.php");


?>
<div class="validation">
<?php



$req = $bdd->prepare('UPDATE utilisateur SET mail = :mail WHERE pseudo = :pseudo');
$req->execute(array(
	'mail' => $_POST['mail'],
	'pseudo' => $_SESSION['pseudo']

	));

echo ("Votre adresse mail a bien ete change ! redirection vers l'interface utilisateur d'ici peu.")

?>
</div>
<?php
header ("Refresh: 5;URL=gestion.php"); //redirection vers URL après 5 secondes.
include("footer.php");
?>