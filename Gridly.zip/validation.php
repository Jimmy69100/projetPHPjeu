
<?php

$upload_cible = 'image';
$nom_image = $_FILES['image']['tmp_name'];
$nom_definitif = $_FILES['image']['name'];
$format_image = $_FILES['image']['type'];


move_uploaded_file($nom_image, "$upload_cible/$nom_definitif");












$req = $bdd->prepare('INSERT INTO article(titre, image, article, article_preview, date, pseudo, type_1, type_2) VALUES(:titre, :image, :article, :article_preview, :date, :pseudo, :type_1, :type_2)');
$req->execute(array(
	'titre' => $_POST['titre'],
	'article' => $_POST['contenu'],
	'article_preview' => $_POST['contenu'],
	'date' => $_POST['date'],
	'image' => $nom_definitif,
	'pseudo' => $_POST['pseudo'],
	'type_1' => $_POST['type'],
	'type_2' => $_POST['type2']
	));
?>


<a class="home" href="index.php">Acceuil</a>
